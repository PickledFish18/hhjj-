
let selectedCharacter = null;

function selectCharacter(color) {
  selectedCharacter = color;
  document.getElementById('character-select').style.display = 'none';
  startGame();
}

function startGame() {
  const socket = io();

  class Player extends Phaser.Physics.Arcade.Sprite {
    constructor(scene, x, y, id, color, isMe) {
      super(scene, x, y, color);
      this.id = id;
      this.isMe = isMe;
      scene.add.existing(this);
      scene.physics.add.existing(this);
      this.setCollideWorldBounds(true);
    }
  }

  class Bullet extends Phaser.Physics.Arcade.Image {
    constructor(scene, x, y, angle) {
      super(scene, x, y, 'bullet');
      scene.add.existing(this);
      scene.physics.add.existing(this);
      scene.physics.velocityFromAngle(angle, 400, this.body.velocity);
      this.setAngle(angle);
      this.setSize(8, 8);
      setTimeout(() => this.destroy(), 2000);
    }
  }

  class GameScene extends Phaser.Scene {
    constructor() {
      super('GameScene');
      this.players = {};
      this.bullets = this.physics.add.group();
    }

    preload() {
      this.load.image('red', 'https://labs.phaser.io/assets/sprites/phaser-dude.png');
      this.load.image('blue', 'https://labs.phaser.io/assets/sprites/mushroom2.png');
      this.load.image('bullet', 'https://labs.phaser.io/assets/sprites/bullet.png');
    }

    create() {
      socket.emit('characterSelected', selectedCharacter);

      socket.on('currentPlayers', players => {
        Object.keys(players).forEach(id => {
          const p = players[id];
          const player = new Player(this, p.x, p.y, id, p.color, id === socket.id);
          this.players[id] = player;
        });
      });

      socket.on('newPlayer', p => {
        const newP = new Player(this, p.x, p.y, p.id, p.color, false);
        this.players[p.id] = newP;
      });

      socket.on('playerMoved', data => {
        const p = this.players[data.id];
        if (p && !p.isMe) p.setPosition(data.x, data.y);
      });

      socket.on('playerDisconnected', id => {
        if (this.players[id]) {
          this.players[id].destroy();
          delete this.players[id];
        }
      });

      socket.on('bulletFired', ({ x, y, angle }) => {
        this.bullets.add(new Bullet(this, x, y, angle));
      });

      // joystick
      this.joystick = nipplejs.create({ zone: document.body, mode: 'static', position: { left: '10%', bottom: '20%' }, color: 'blue' });
      this.joystick.on('move', (_, data) => {
        if (!data) return;
        const rad = data.angle.radian;
        this.moveDir = { x: Math.cos(rad), y: Math.sin(rad) };
      });
      this.joystick.on('end', () => this.moveDir = null);

      // attack joystick
      this.firestick = nipplejs.create({ zone: document.body, mode: 'static', position: { right: '10%', bottom: '20%' }, color: 'red' });
      this.firestick.on('move', (_, data) => {
        if (!data) return;
        const angleDeg = data.angle.degree;
        const me = this.players[socket.id];
        if (me) {
          const bullet = new Bullet(this, me.x, me.y, angleDeg);
          this.bullets.add(bullet);
          socket.emit('fireBullet', { x: me.x, y: me.y, angle: angleDeg });
        }
      });
    }

    update() {
      const me = this.players[socket.id];
      if (!me) return;

      me.setVelocity(0);
      if (this.moveDir) {
        me.setVelocityX(this.moveDir.x * 150);
        me.setVelocityY(this.moveDir.y * 150);
        socket.emit('playerMovement', { x: me.x, y: me.y });
      }
    }
  }

  const config = {
    type: Phaser.AUTO,
    width: window.innerWidth,
    height: window.innerHeight,
    parent: 'game',
    physics: { default: 'arcade' },
    scene: GameScene
  };

  new Phaser.Game(config);
}
